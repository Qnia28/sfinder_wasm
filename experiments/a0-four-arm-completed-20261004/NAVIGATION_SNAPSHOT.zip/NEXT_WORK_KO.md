# 다음 작업 인계 — 실험 정리 및 Sol 후속

## 현재 시작점 (2026-10-04 갱신)

- **[4군 비교 준비 완료](tools/validation/a0-four-arm-preparation-20261003/RESULT_KO.md)**: R/A0/M1(조기종료하한)/M2(마지막형제기록제거)를독립구현. 기존121개+hotspot1개,122입력×10blocks×4군+환경80calls=4,960calls일정고정. 로컬합성검사통과, GitHub push·Actions·실제입력native0. 실행승인전launch.json없음. LinuxRust실행/WASMhash/cgroup gate는hosted미확인으로남김.
- **[4군Actions/검산완료](tools/validation/a0-four-arm-execution-20261004/RESULT_KO.md)**: run `37134463920`, source `f4716e1f…`. Linux원본/control전체byte동일73224bda…, Rustdebug/release6mode통과. 비계측4,960calls+분리work20calls,122입력완전10blocks,누락/error/OOM/timeout0, states/품질/IDs보존. 별도진단5개에서M1boundword·M2trail감소확인.
- 최초run37134128882는CRLF/LFfixture오류로실제입력0calls, canonicalhash만교정해재실행. origin15:41:25Z유지, 최종15:58:16Z종료·0.618889runner-hours. 캠페인닫힘/watcher없음. 입력/일정/Rust및원sealed증거보존.
- 환경control2건(reservedR/host3와M1/host0) >10%로예약88개관련비교는환경민감. 개발34개joint비교에서M1개선18개/M2개선5개. M2/A0전체직접비교개선16개지만새악화2개(board107bagordinary1.1642, board119T1.1497)가남음. M1을검토우선후보로만유지, M2일반속도개선주장불가. 원p95=1.197846>1.10보류유지;자동재캠페인/수정결합/Dev/main/배포없음.

- **[공통 테스트 지침 v1.1](tools/validation/TESTING_RULES_KO.md)**: 개선/악화 각각 상위10%, 반복 편차10% 이상 입력을 R/A10쌍으로 재확인. 단순 하네스 오류는 자율 교정 후 동일 예산에서 재시도한다.
- [전체 실험 인덱스](tools/validation/README_KO.md) / [종합 해석](tools/validation/experiment-review-20261003/SYNTHESIS_KO.md).
- **[Sol 인계](tools/validation/experiment-review-20261003/HANDOFF_SOL_KO.md)**: `board-111--restricted-split--ordinary` 독립 fixed-K exact 증명 → 기존 enlarged168개로 대상/예산 산출 → 새10쌍 재확인.
- **[완료한 후속 실행](tools/validation/a0-proof-retest-completed-20261003/RESULT_KO.md)**: exact1개 독립 증명 완료(1,704states/53.4ms, 품질·stable ID 일치). 고정121개 R/A10쌍 총2,460calls 감사 통과. 원 >10% 악화 경보10개는 같은 기준 재현0개; 새3개 수ms대 악화 경보는 보존했다. 캠페인 종료, watcher 없음.
- A0 제품 통합은 보류. 독립 exact 공백은 해소됐지만 원 reserved p95 실패는 유지한다. 현재 프로파일의 공통lower-bound hotspot과 과거9V45 이상치 기전은 별개이며 후자는 미해결이다.
- 후속 캠페인 origin `2026-10-03T10:02:53Z` 유지, 마지막job10:47:18Z, 총0.224444runner-hours로 종료. 다음 승격에는 별도 승인된 고정 전체 모집단 확인 계획이 필요하며232/675확인·추가 native·Dev/main/배포를 자동 시작하지 않는다.

## 이전 saves 인계 (역사 기록)

작업 루트: `D:\AI\sfinder-wasm` (루트 자체는 Git repo가 아니다).
제품 repo: `D:\AI\sfinder-wasm\dev-branch`.
현재 제품 branch: `integration/saves-minimal-20261002`.

## 완료한 saves 작업

- A5 alias 파싱 정확성 수정 + A4 캐시 보존 상한만 최소 통합했다.
- 조합 회귀는 고유183개 모두 통과. 기존 WASM·Rust·saves 기본값·3체제 정책은 변경하지 않았다.
- B4 현재 wrapper/direct Rust/WASM 묶음은 통합하지 않았다. A6와 다른 후보도 archive 실험 자료로만 남긴다.
- 실험 결정·원시 결과·실패 이력·Git 이력·핵심 코드: [아카이브 인덱스](archive/saves-experiments-20261002/README_KO.md).
- local main `187fbf9`, remote main `03b6377`은 유지했다. merge·배포·새 CI push 없음.

## 3체제 후속 작업 시작점

- [제품 현재 상태](dev-branch/docs/DEV_BRANCH_STATUS.md)
- [다음 routing 설계](tools/validation/secondary-routing-design-20260929/DESIGN_KO.md)
- `dev-branch/src/min-cover-three-engine.mjs`
- `dev-branch/src/secondary-engine-runner.mjs`
- `dev-branch/src/min-cover-components.mjs`
- `dev-branch/tests/secondary-three-engine.test.mjs`
- `muse/integrated-improve/`와 `tools/validation/secondary-*`는 이번 정리에서 보호했다.

현재 정책은 trivial→integrated100K→threshold, primaryHard는threshold부터 시작한다.
auto는60초뒤CP1을합류시키며Rust는계속한다. 단일활성엔진대체는미검증이다.
최소K·원본중복행가중quality·stable-ID proof·취소/worker회수를유지한다.
다음연구는새가설/manifest로진행하고옛saves workflow를재활성화하지않는다.

PowerShell 설정은 `. D:\AI\sfinder-wasm\tools\activate.ps1`로 현재 셸에만 적용할 수 있다.
CP 검사에서 Node JSPI가 필요하면 `--experimental-wasm-stack-switching --test-isolation=none`을 사용하고 실제 pass/skip을 구분한다.
