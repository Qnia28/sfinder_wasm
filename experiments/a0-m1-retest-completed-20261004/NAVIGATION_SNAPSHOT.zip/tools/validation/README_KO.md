# 실험·검증 시작점

**현재 상태: A0 후보는 유지, 제품 통합은 보류.** [독립 exact1개 증명과 고정121개·10쌍 재테스트 완료](a0-proof-retest-completed-20261003/RESULT_KO.md). 원 악화 경보10개의 >10% 악화는 재현되지 않았지만 새3개 단기 호출 경보가 남았고, 기존 reserved p95 실패는 유지한다. Dev 보호 HEAD는 `c0cb2a048e7275bfea587d176b1954efff0a8a08`이다.

**후속 완료:** [4군 비교 Actions 검산](a0-four-arm-execution-20261004/RESULT_KO.md). 원본/control전체byte일치, 비계측4,960calls+분리work20calls모두통과. M1작업감소·개선신호가강하지만환경경보2건으로예약88개의관련비교는환경민감; M2/A0새악화2개보존. 원제품gate보류유지. [최초준비](a0-four-arm-preparation-20261003/RESULT_KO.md)는당시미실행기록으로보존한다.

출판증거는isolatedbranch의 `27e51f4`에push했고Git줄바꿈정규화10개에대한exact-byte ZIP거울을 `45f9035`로추가했다. [출판byte검증영수증](a0-four-arm-publication-verified-20261004.json): 원봉인6,952파일전체재구성/hash일치, 원봉인변경없음·추가Actions/native0.

**최신완료:** [M1한번재테스트·판정](a0-m1-retest-20261004/RESULT_KO.md). 고정122개·세비교100쌍/10runner·73,320calls독립검산통과. M1/R빠른pairedmedian91개(8/10runner방향55개),M1/A0빠른94개(같은방향54개). 환경22/60경보로모두엄격환경민감분류유지. **선택가능A0+M1의통합구현단계진행권고,기본값승격아님.** 추가재테스트/구현/Dev/main/배포없음. 개별10%악화는통합자동거부조건이아니다.

## 다음 작업자가 읽을 문서

1. **[공통 테스트 지침 v1.1](TESTING_RULES_KO.md)** — 개선/악화 각각 상위10%, 반복 편차10% 이상, 고정10쌍 재확인. 단순 하네스 오류의 자율 교정·동일 예산 재시도 허용.
2. [실험 종합·해석](experiment-review-20261003/SYNTHESIS_KO.md) — 무엇을 확인했고 무엇이 아직 미해결인지.
3. [Sol 인계](experiment-review-20261003/HANDOFF_SOL_KO.md) — exact1개 → 기존 자료 선별/예산 → 새 재확인.
4. [전체 디렉터리 인덱스](experiment-review-20261003/CATALOG_KO.md) / [기계 판독 목록](experiment-review-20261003/CATALOG.json).

## A0 핵심 증거 — 읽는 목적에 따라 선택

| 목적 | 원문 |
|---|---|
| 입력/최소K/seed의 출처 | [capture](integrated-capture-20261002/RESULT_KO.md) |
| A0/B10/B6 개발 비교, 독립threshold129개 | [benchmark](integrated-bench-20261002/MAIN_RESULT_KO.md) |
| 최소 제품 연결과 전체 route의 실패 | [product integration](a0-product-integration-20261003/RESULT_KO.md) |
| **유효한 p95 실패와 exact 공백** | [enlarged integrated 확인](a0-integrated-revalidation-20261003/RESULT_KO.md) |
| **독립 exact 공백 해소·10쌍 재확인 완료·새 경보3개** | [증명 및 재테스트](a0-proof-retest-completed-20261003/RESULT_KO.md) |
| **R/A0/M1/M2 비교 준비 — 실행 미승인** | [4군 준비](a0-four-arm-preparation-20261003/RESULT_KO.md) |
| **4군4,980calls 검산 완료 — M1우선후보/M2새악화·환경민감/제품HOLD** | [4군 완료](a0-four-arm-execution-20261004/RESULT_KO.md) |
| cold/compiled/warm과 baseline 대조 | [32입력 원인 진단](a0-cause-diagnosis-20261003/RESULT_KO.md) |
| 선행 export 실행과 affinity | [순서 진단](a0-order-diagnosis-20261003/RESULT_KO.md) |
| 강제 compiler 정책과 정적 호출 그래프 | [tier 진단](a0-tier-diagnosis-20261003/RESULT_KO.md) |
| **현재 비용 위치와 최종 대응** | [실행 프로파일](a0-execution-diagnosis-20261003/RESULT_KO.md) |

과거 plan은 당시 제안/승인 범위다. 뒤의 실행 결과보다 우선하지 않는다. 특히 구계획의 formal232개 확인과675 재캠페인은 실행된 것으로 세지 않는다.

## 보존 방식

원 실험 폴더·로그·실패·원문·hash·bundle·seal을 이동/삭제하지 않고, 이 인덱스에서 논리적으로 묶었다. 원문에 “다음은…”이라고 적힌 부분은 그 문서 시점의 상태다. 현재 우선순위는 종합 문서와 Sol 인계를 따른다.

이전 saves 통합 역사는 [별도 아카이브](../../archive/saves-experiments-20261002/README_KO.md), 더 오래된 자료는 [archive](../../archive/)를 참조한다. 기존 secondary/CP/worker 등 연구는 전체 디렉터리 인덱스에 연결하되 A0의 최신 성능 PASS 근거로 자동 전용하지 않는다.

`src/wasm/rust/node_modules`는 junction일 수 있는 실행 지원 경로다. 증거를 정리한다는 이유로 이 경로를 재귀 이동·복사·삭제하지 않는다.
